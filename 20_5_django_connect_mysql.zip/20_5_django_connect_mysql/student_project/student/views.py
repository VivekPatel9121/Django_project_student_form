from django.shortcuts import render, redirect
from .models import Student

# Create your views here.
class StudentView:
    def student_list(request):
        if request.method == 'POST':
            name = request.POST.get('name')
            age = request.POST.get('age')
            email = request.POST.get('email')
            if email == '':
                email = None
            
            student = Student(name=name, age=age, email=email)
            student.save()
            return redirect('student_submit')
        return render(request, 'student/index.html')
    
class StudentSubmitView:
    def student_submit(request):
        return render(request, 'student/submit.html')
    
class StudentupdateView:
    def student_update(request, id):
        student = Student.objects.get(id=id)
        if request.method == 'POST':
            student.name = request.POST.get('name')
            student.age = request.POST.get('age')
            email = request.POST.get('email')
            if email == '':
                student.email = None
            else:
                student.email = email
            student.save()
            return redirect('student_submit')
        return render(request, 'student/update.html', {'student': student})
    
class StudentDeleteView:
    def student_delete(request, id):
        student = Student.objects.get(id=id)
        student.delete()
        return redirect('student_submit')   
    
    

