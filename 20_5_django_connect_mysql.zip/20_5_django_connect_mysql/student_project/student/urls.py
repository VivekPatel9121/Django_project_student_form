from django.urls import path
from . import views
urlpatterns = [
    path('', views.StudentView.student_list, name='student_list'),
    path('submit/', views.StudentSubmitView.student_submit, name='student_submit'),
    path('update/<int:id>/', views.StudentupdateView.student_update, name='student_update'),
    path('delete/<int:id>/', views.StudentDeleteView.student_delete, name='student_delete'),
]
    